namespace CourseWork
{
    public partial class Form1 : Form
    {
        bool visionCheck = true;
        public Form1()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            if (visionCheck)
            {
                passwordTB.UseSystemPasswordChar = false;
                visionCheck = false;
                string imagePath = @"..\..\..\hide.png";
                pictureBox1.Image = Image.FromFile(imagePath);
            }
            else
            {
                passwordTB.UseSystemPasswordChar = true;
                visionCheck = true;
                string imagePath = @"..\..\..\view.png";
                pictureBox1.Image = Image.FromFile(imagePath);
            }
        }

        private void inputBtn_Click(object sender, EventArgs e)
        {
            if (loginTB.Text == "admin" && passwordTB.Text == "admin")
            {
                Form Form2 = new Form2();
                Form2.Show();
                this.Hide();
            }
            else 
            {
                MessageBox.Show("������������ ���� ��/��� ������");
            }

        }
    }
}
