﻿namespace CourseWork
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tabControl1 = new TabControl();
            tabPage1 = new TabPage();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            pictureBox1 = new PictureBox();
            numericBatch = new NumericUpDown();
            buttonLoadXML = new Button();
            buttonClear = new Button();
            buttonSaveXML = new Button();
            buttonRedact = new Button();
            buttonDelete = new Button();
            buttonAdd = new Button();
            dateTimePicker = new DateTimePicker();
            textBoxCountry = new TextBox();
            textBoxMaker = new TextBox();
            textBoxName = new TextBox();
            productsDataGridView = new DataGridView();
            numberColumn = new DataGridViewTextBoxColumn();
            nameColumn = new DataGridViewTextBoxColumn();
            makerColumn = new DataGridViewTextBoxColumn();
            importCountryColumn = new DataGridViewTextBoxColumn();
            batchSizeColumn = new DataGridViewTextBoxColumn();
            dateColumn = new DataGridViewTextBoxColumn();
            tabPage2 = new TabPage();
            textBoxResult = new TextBox();
            buttonFind1 = new Button();
            comboBoxProducts = new ComboBox();
            label6 = new Label();
            FindDataGridView1 = new DataGridView();
            dataGridViewTextBoxColumn1 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn2 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn3 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn4 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn5 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn6 = new DataGridViewTextBoxColumn();
            tabPage3 = new TabPage();
            listBox1 = new ListBox();
            label8 = new Label();
            buttonFind3 = new Button();
            dateTimePicker2 = new DateTimePicker();
            dateTimePicker1 = new DateTimePicker();
            buttonFind2 = new Button();
            FindDataGridView2 = new DataGridView();
            dataGridViewTextBoxColumn19 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn20 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn21 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn22 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn23 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn24 = new DataGridViewTextBoxColumn();
            label9 = new Label();
            tabControl1.SuspendLayout();
            tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericBatch).BeginInit();
            ((System.ComponentModel.ISupportInitialize)productsDataGridView).BeginInit();
            tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)FindDataGridView1).BeginInit();
            tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)FindDataGridView2).BeginInit();
            SuspendLayout();
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(tabPage1);
            tabControl1.Controls.Add(tabPage2);
            tabControl1.Controls.Add(tabPage3);
            tabControl1.Location = new Point(0, -1);
            tabControl1.Multiline = true;
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(1256, 684);
            tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            tabPage1.BackColor = Color.PapayaWhip;
            tabPage1.Controls.Add(label5);
            tabPage1.Controls.Add(label4);
            tabPage1.Controls.Add(label3);
            tabPage1.Controls.Add(label2);
            tabPage1.Controls.Add(label1);
            tabPage1.Controls.Add(pictureBox1);
            tabPage1.Controls.Add(numericBatch);
            tabPage1.Controls.Add(buttonLoadXML);
            tabPage1.Controls.Add(buttonClear);
            tabPage1.Controls.Add(buttonSaveXML);
            tabPage1.Controls.Add(buttonRedact);
            tabPage1.Controls.Add(buttonDelete);
            tabPage1.Controls.Add(buttonAdd);
            tabPage1.Controls.Add(dateTimePicker);
            tabPage1.Controls.Add(textBoxCountry);
            tabPage1.Controls.Add(textBoxMaker);
            tabPage1.Controls.Add(textBoxName);
            tabPage1.Controls.Add(productsDataGridView);
            tabPage1.Location = new Point(4, 29);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(1248, 651);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "Головна сторінка";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Bahnschrift", 9F);
            label5.Location = new Point(1029, 14);
            label5.Name = "label5";
            label5.Size = new Size(127, 18);
            label5.TabIndex = 18;
            label5.Text = "Дата постачання";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Bahnschrift", 9F);
            label4.Location = new Point(783, 14);
            label4.Name = "label4";
            label4.Size = new Size(139, 18);
            label4.TabIndex = 17;
            label4.Text = "Об’єм партії товару";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Bahnschrift", 9F);
            label3.Location = new Point(543, 14);
            label3.Name = "label3";
            label3.Size = new Size(119, 18);
            label3.TabIndex = 16;
            label3.Text = "Країна імпортер";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Bahnschrift", 9F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label2.Location = new Point(288, 14);
            label2.Name = "label2";
            label2.Size = new Size(77, 18);
            label2.TabIndex = 15;
            label2.Text = "Виробник";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Bahnschrift", 9F);
            label1.Location = new Point(18, 14);
            label1.Name = "label1";
            label1.Size = new Size(49, 18);
            label1.TabIndex = 14;
            label1.Text = "Назва";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.products;
            pictureBox1.Location = new Point(1081, 482);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(145, 118);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 13;
            pictureBox1.TabStop = false;
            // 
            // numericBatch
            // 
            numericBatch.Font = new Font("Bahnschrift", 9F);
            numericBatch.Location = new Point(783, 40);
            numericBatch.Maximum = new decimal(new int[] { 276447231, 23283, 0, 0 });
            numericBatch.Name = "numericBatch";
            numericBatch.Size = new Size(196, 26);
            numericBatch.TabIndex = 12;
            // 
            // buttonLoadXML
            // 
            buttonLoadXML.BackColor = Color.BurlyWood;
            buttonLoadXML.FlatStyle = FlatStyle.Popup;
            buttonLoadXML.Font = new Font("Bahnschrift", 9F);
            buttonLoadXML.Location = new Point(749, 571);
            buttonLoadXML.Name = "buttonLoadXML";
            buttonLoadXML.Size = new Size(268, 29);
            buttonLoadXML.TabIndex = 11;
            buttonLoadXML.Text = "Завантажити XML";
            buttonLoadXML.UseVisualStyleBackColor = false;
            buttonLoadXML.Click += buttonLoadXML_Click;
            // 
            // buttonClear
            // 
            buttonClear.BackColor = Color.BurlyWood;
            buttonClear.FlatStyle = FlatStyle.Popup;
            buttonClear.Font = new Font("Bahnschrift", 9F);
            buttonClear.Location = new Point(386, 571);
            buttonClear.Name = "buttonClear";
            buttonClear.Size = new Size(268, 29);
            buttonClear.TabIndex = 10;
            buttonClear.Text = "Почистити";
            buttonClear.UseVisualStyleBackColor = false;
            buttonClear.Click += buttonClear_Click;
            // 
            // buttonSaveXML
            // 
            buttonSaveXML.BackColor = Color.BurlyWood;
            buttonSaveXML.FlatStyle = FlatStyle.Popup;
            buttonSaveXML.Font = new Font("Bahnschrift", 9F);
            buttonSaveXML.Location = new Point(18, 571);
            buttonSaveXML.Name = "buttonSaveXML";
            buttonSaveXML.Size = new Size(268, 29);
            buttonSaveXML.TabIndex = 9;
            buttonSaveXML.Text = "Зберегти XML";
            buttonSaveXML.UseVisualStyleBackColor = false;
            buttonSaveXML.Click += buttonSaveXML_Click;
            // 
            // buttonRedact
            // 
            buttonRedact.BackColor = Color.BurlyWood;
            buttonRedact.FlatStyle = FlatStyle.Popup;
            buttonRedact.Font = new Font("Bahnschrift", 9F);
            buttonRedact.Location = new Point(1070, 267);
            buttonRedact.Name = "buttonRedact";
            buttonRedact.Size = new Size(162, 56);
            buttonRedact.TabIndex = 8;
            buttonRedact.Text = "Редагувати";
            buttonRedact.UseVisualStyleBackColor = false;
            buttonRedact.Click += buttonRedact_Click;
            // 
            // buttonDelete
            // 
            buttonDelete.BackColor = Color.BurlyWood;
            buttonDelete.FlatStyle = FlatStyle.Popup;
            buttonDelete.Font = new Font("Bahnschrift", 9F);
            buttonDelete.Location = new Point(1070, 368);
            buttonDelete.Name = "buttonDelete";
            buttonDelete.Size = new Size(162, 56);
            buttonDelete.TabIndex = 7;
            buttonDelete.Text = "Видалити";
            buttonDelete.UseVisualStyleBackColor = false;
            buttonDelete.Click += buttonDelete_Click;
            // 
            // buttonAdd
            // 
            buttonAdd.BackColor = Color.BurlyWood;
            buttonAdd.FlatStyle = FlatStyle.Popup;
            buttonAdd.Font = new Font("Bahnschrift", 9F);
            buttonAdd.Location = new Point(1070, 170);
            buttonAdd.Name = "buttonAdd";
            buttonAdd.Size = new Size(162, 56);
            buttonAdd.TabIndex = 6;
            buttonAdd.Text = "Додати";
            buttonAdd.UseVisualStyleBackColor = false;
            buttonAdd.Click += buttonAdd_Click;
            // 
            // dateTimePicker
            // 
            dateTimePicker.Font = new Font("Bahnschrift", 9F);
            dateTimePicker.Location = new Point(1029, 40);
            dateTimePicker.Name = "dateTimePicker";
            dateTimePicker.Size = new Size(197, 26);
            dateTimePicker.TabIndex = 5;
            // 
            // textBoxCountry
            // 
            textBoxCountry.Font = new Font("Bahnschrift", 9F);
            textBoxCountry.Location = new Point(543, 40);
            textBoxCountry.Name = "textBoxCountry";
            textBoxCountry.Size = new Size(193, 26);
            textBoxCountry.TabIndex = 3;
            textBoxCountry.KeyPress += textBoxCountry_KeyPress;
            // 
            // textBoxMaker
            // 
            textBoxMaker.Font = new Font("Bahnschrift", 9F);
            textBoxMaker.Location = new Point(288, 40);
            textBoxMaker.Name = "textBoxMaker";
            textBoxMaker.Size = new Size(204, 26);
            textBoxMaker.TabIndex = 2;
            // 
            // textBoxName
            // 
            textBoxName.Font = new Font("Bahnschrift", 9F);
            textBoxName.Location = new Point(18, 40);
            textBoxName.Name = "textBoxName";
            textBoxName.Size = new Size(201, 26);
            textBoxName.TabIndex = 1;
            // 
            // productsDataGridView
            // 
            productsDataGridView.AllowUserToAddRows = false;
            productsDataGridView.BackgroundColor = Color.Linen;
            productsDataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            productsDataGridView.Columns.AddRange(new DataGridViewColumn[] { numberColumn, nameColumn, makerColumn, importCountryColumn, batchSizeColumn, dateColumn });
            productsDataGridView.Location = new Point(3, 100);
            productsDataGridView.Name = "productsDataGridView";
            productsDataGridView.RowHeadersWidth = 51;
            productsDataGridView.Size = new Size(1042, 425);
            productsDataGridView.TabIndex = 0;
            productsDataGridView.SelectionChanged += productsDataGridView_SelectionChanged;
            // 
            // numberColumn
            // 
            numberColumn.HeaderText = "№";
            numberColumn.MinimumWidth = 6;
            numberColumn.Name = "numberColumn";
            numberColumn.Width = 75;
            // 
            // nameColumn
            // 
            nameColumn.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            nameColumn.HeaderText = "Назва";
            nameColumn.MinimumWidth = 6;
            nameColumn.Name = "nameColumn";
            // 
            // makerColumn
            // 
            makerColumn.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            makerColumn.HeaderText = "Виробник";
            makerColumn.MinimumWidth = 6;
            makerColumn.Name = "makerColumn";
            // 
            // importCountryColumn
            // 
            importCountryColumn.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            importCountryColumn.HeaderText = "Країна імпортер";
            importCountryColumn.MinimumWidth = 6;
            importCountryColumn.Name = "importCountryColumn";
            // 
            // batchSizeColumn
            // 
            batchSizeColumn.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            batchSizeColumn.HeaderText = "Об’єм партії товару";
            batchSizeColumn.MinimumWidth = 6;
            batchSizeColumn.Name = "batchSizeColumn";
            // 
            // dateColumn
            // 
            dateColumn.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dateColumn.HeaderText = "Дата постачання";
            dateColumn.MinimumWidth = 6;
            dateColumn.Name = "dateColumn";
            // 
            // tabPage2
            // 
            tabPage2.BackColor = Color.PapayaWhip;
            tabPage2.Controls.Add(textBoxResult);
            tabPage2.Controls.Add(buttonFind1);
            tabPage2.Controls.Add(comboBoxProducts);
            tabPage2.Controls.Add(label6);
            tabPage2.Controls.Add(FindDataGridView1);
            tabPage2.Location = new Point(4, 29);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(1248, 651);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "Пошук 1";
            // 
            // textBoxResult
            // 
            textBoxResult.Font = new Font("Bahnschrift", 9F);
            textBoxResult.Location = new Point(241, 107);
            textBoxResult.Name = "textBoxResult";
            textBoxResult.Size = new Size(125, 26);
            textBoxResult.TabIndex = 6;
            // 
            // buttonFind1
            // 
            buttonFind1.BackColor = Color.BurlyWood;
            buttonFind1.FlatStyle = FlatStyle.Popup;
            buttonFind1.Font = new Font("Bahnschrift", 9F);
            buttonFind1.Location = new Point(522, 106);
            buttonFind1.Name = "buttonFind1";
            buttonFind1.Size = new Size(94, 29);
            buttonFind1.TabIndex = 5;
            buttonFind1.Text = "Пошук";
            buttonFind1.UseVisualStyleBackColor = false;
            buttonFind1.Click += buttonFind1_Click;
            // 
            // comboBoxProducts
            // 
            comboBoxProducts.Font = new Font("Bahnschrift", 9F);
            comboBoxProducts.FormattingEnabled = true;
            comboBoxProducts.Location = new Point(35, 107);
            comboBoxProducts.Name = "comboBoxProducts";
            comboBoxProducts.Size = new Size(151, 26);
            comboBoxProducts.TabIndex = 3;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Bahnschrift SemiBold", 12F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label6.Location = new Point(35, 39);
            label6.Name = "label6";
            label6.Size = new Size(693, 24);
            label6.TabIndex = 2;
            label6.Text = "Пошук країн, з яких імпортується товар та загальний об’єм його експорту";
            // 
            // FindDataGridView1
            // 
            FindDataGridView1.AllowUserToAddRows = false;
            FindDataGridView1.BackgroundColor = Color.Linen;
            FindDataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            FindDataGridView1.Columns.AddRange(new DataGridViewColumn[] { dataGridViewTextBoxColumn1, dataGridViewTextBoxColumn2, dataGridViewTextBoxColumn3, dataGridViewTextBoxColumn4, dataGridViewTextBoxColumn5, dataGridViewTextBoxColumn6 });
            FindDataGridView1.Location = new Point(15, 196);
            FindDataGridView1.Name = "FindDataGridView1";
            FindDataGridView1.RowHeadersWidth = 51;
            FindDataGridView1.Size = new Size(1222, 435);
            FindDataGridView1.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn1
            // 
            dataGridViewTextBoxColumn1.HeaderText = "№";
            dataGridViewTextBoxColumn1.MinimumWidth = 6;
            dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            dataGridViewTextBoxColumn1.Width = 75;
            // 
            // dataGridViewTextBoxColumn2
            // 
            dataGridViewTextBoxColumn2.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewTextBoxColumn2.HeaderText = "Назва";
            dataGridViewTextBoxColumn2.MinimumWidth = 6;
            dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            dataGridViewTextBoxColumn3.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewTextBoxColumn3.HeaderText = "Виробник";
            dataGridViewTextBoxColumn3.MinimumWidth = 6;
            dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            dataGridViewTextBoxColumn4.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewTextBoxColumn4.HeaderText = "Країна імпортер";
            dataGridViewTextBoxColumn4.MinimumWidth = 6;
            dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            dataGridViewTextBoxColumn5.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewTextBoxColumn5.HeaderText = "Об’єм партії товару";
            dataGridViewTextBoxColumn5.MinimumWidth = 6;
            dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            dataGridViewTextBoxColumn6.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewTextBoxColumn6.HeaderText = "Дата постачання";
            dataGridViewTextBoxColumn6.MinimumWidth = 6;
            dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // tabPage3
            // 
            tabPage3.BackColor = Color.PapayaWhip;
            tabPage3.Controls.Add(listBox1);
            tabPage3.Controls.Add(label8);
            tabPage3.Controls.Add(buttonFind3);
            tabPage3.Controls.Add(dateTimePicker2);
            tabPage3.Controls.Add(dateTimePicker1);
            tabPage3.Controls.Add(buttonFind2);
            tabPage3.Controls.Add(FindDataGridView2);
            tabPage3.Controls.Add(label9);
            tabPage3.Location = new Point(4, 29);
            tabPage3.Name = "tabPage3";
            tabPage3.Size = new Size(1248, 651);
            tabPage3.TabIndex = 2;
            tabPage3.Text = "Пошук 2";
            // 
            // listBox1
            // 
            listBox1.BackColor = Color.Linen;
            listBox1.Font = new Font("Bahnschrift", 9F);
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 18;
            listBox1.Location = new Point(35, 486);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(323, 130);
            listBox1.TabIndex = 18;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Bahnschrift SemiBold", 12F, FontStyle.Bold);
            label8.Location = new Point(35, 452);
            label8.Name = "label8";
            label8.Size = new Size(496, 24);
            label8.TabIndex = 17;
            label8.Text = "Пошук товарів, які не мали попиту за останні місяці.";
            // 
            // buttonFind3
            // 
            buttonFind3.BackColor = Color.BurlyWood;
            buttonFind3.FlatStyle = FlatStyle.Popup;
            buttonFind3.Font = new Font("Bahnschrift", 9F);
            buttonFind3.Location = new Point(394, 500);
            buttonFind3.Name = "buttonFind3";
            buttonFind3.Size = new Size(94, 29);
            buttonFind3.TabIndex = 16;
            buttonFind3.Text = "Пошук";
            buttonFind3.UseVisualStyleBackColor = false;
            buttonFind3.Click += buttonFind3_Click;
            // 
            // dateTimePicker2
            // 
            dateTimePicker2.Font = new Font("Bahnschrift", 9F);
            dateTimePicker2.Location = new Point(35, 128);
            dateTimePicker2.Name = "dateTimePicker2";
            dateTimePicker2.Size = new Size(250, 26);
            dateTimePicker2.TabIndex = 15;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Font = new Font("Bahnschrift", 9F);
            dateTimePicker1.Location = new Point(35, 85);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(250, 26);
            dateTimePicker1.TabIndex = 14;
            // 
            // buttonFind2
            // 
            buttonFind2.BackColor = Color.BurlyWood;
            buttonFind2.FlatStyle = FlatStyle.Popup;
            buttonFind2.Font = new Font("Bahnschrift", 9F);
            buttonFind2.Location = new Point(394, 106);
            buttonFind2.Name = "buttonFind2";
            buttonFind2.Size = new Size(94, 29);
            buttonFind2.TabIndex = 13;
            buttonFind2.Text = "Пошук";
            buttonFind2.UseVisualStyleBackColor = false;
            buttonFind2.Click += buttonFind2_Click;
            // 
            // FindDataGridView2
            // 
            FindDataGridView2.AllowUserToAddRows = false;
            FindDataGridView2.BackgroundColor = Color.Linen;
            FindDataGridView2.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            FindDataGridView2.Columns.AddRange(new DataGridViewColumn[] { dataGridViewTextBoxColumn19, dataGridViewTextBoxColumn20, dataGridViewTextBoxColumn21, dataGridViewTextBoxColumn22, dataGridViewTextBoxColumn23, dataGridViewTextBoxColumn24 });
            FindDataGridView2.Location = new Point(15, 196);
            FindDataGridView2.Name = "FindDataGridView2";
            FindDataGridView2.RowHeadersWidth = 51;
            FindDataGridView2.Size = new Size(1226, 234);
            FindDataGridView2.TabIndex = 12;
            // 
            // dataGridViewTextBoxColumn19
            // 
            dataGridViewTextBoxColumn19.HeaderText = "№";
            dataGridViewTextBoxColumn19.MinimumWidth = 6;
            dataGridViewTextBoxColumn19.Name = "dataGridViewTextBoxColumn19";
            dataGridViewTextBoxColumn19.Width = 75;
            // 
            // dataGridViewTextBoxColumn20
            // 
            dataGridViewTextBoxColumn20.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewTextBoxColumn20.HeaderText = "Назва";
            dataGridViewTextBoxColumn20.MinimumWidth = 6;
            dataGridViewTextBoxColumn20.Name = "dataGridViewTextBoxColumn20";
            // 
            // dataGridViewTextBoxColumn21
            // 
            dataGridViewTextBoxColumn21.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewTextBoxColumn21.HeaderText = "Виробник";
            dataGridViewTextBoxColumn21.MinimumWidth = 6;
            dataGridViewTextBoxColumn21.Name = "dataGridViewTextBoxColumn21";
            // 
            // dataGridViewTextBoxColumn22
            // 
            dataGridViewTextBoxColumn22.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewTextBoxColumn22.HeaderText = "Країна імпортер";
            dataGridViewTextBoxColumn22.MinimumWidth = 6;
            dataGridViewTextBoxColumn22.Name = "dataGridViewTextBoxColumn22";
            // 
            // dataGridViewTextBoxColumn23
            // 
            dataGridViewTextBoxColumn23.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewTextBoxColumn23.HeaderText = "Об’єм партії товару";
            dataGridViewTextBoxColumn23.MinimumWidth = 6;
            dataGridViewTextBoxColumn23.Name = "dataGridViewTextBoxColumn23";
            // 
            // dataGridViewTextBoxColumn24
            // 
            dataGridViewTextBoxColumn24.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewTextBoxColumn24.HeaderText = "Дата постачання";
            dataGridViewTextBoxColumn24.MinimumWidth = 6;
            dataGridViewTextBoxColumn24.Name = "dataGridViewTextBoxColumn24";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Bahnschrift SemiBold", 12F, FontStyle.Bold);
            label9.Location = new Point(35, 39);
            label9.Name = "label9";
            label9.Size = new Size(634, 24);
            label9.TabIndex = 11;
            label9.Text = "Пошук товарів, які мають найбільший попит в заданий період часу";
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.PapayaWhip;
            ClientSize = new Size(1257, 684);
            Controls.Add(tabControl1);
            Name = "Form2";
            Text = "Form2";
            FormClosed += Form2_FormClosed;
            tabControl1.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericBatch).EndInit();
            ((System.ComponentModel.ISupportInitialize)productsDataGridView).EndInit();
            tabPage2.ResumeLayout(false);
            tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)FindDataGridView1).EndInit();
            tabPage3.ResumeLayout(false);
            tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)FindDataGridView2).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private TabControl tabControl1;
        private TabPage tabPage1;
        private TabPage tabPage2;
        private DataGridView productsDataGridView;
        private Button buttonSaveXML;
        private Button buttonRedact;
        private Button buttonDelete;
        private Button buttonAdd;
        private DateTimePicker dateTimePicker;
        private TextBox textBoxCountry;
        private TextBox textBoxMaker;
        private TextBox textBoxName;
        private NumericUpDown numericBatch;
        private Button buttonLoadXML;
        private Button buttonClear;
        private DataGridViewTextBoxColumn numberColumn;
        private DataGridViewTextBoxColumn nameColumn;
        private DataGridViewTextBoxColumn makerColumn;
        private DataGridViewTextBoxColumn importCountryColumn;
        private DataGridViewTextBoxColumn batchSizeColumn;
        private DataGridViewTextBoxColumn dateColumn;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private PictureBox pictureBox1;
        private Label label6;
        private DataGridView FindDataGridView1;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private Button buttonFind1;
        private TextBox textBox1;
        private ComboBox comboBoxProducts;
        private TabPage tabPage3;
        private Button buttonFind2;
        private DataGridView FindDataGridView2;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn19;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn20;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn21;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn22;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn23;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn24;
        private Label label9;
        private TextBox textBoxResult;
        private DateTimePicker dateTimePicker2;
        private DateTimePicker dateTimePicker1;
        private ListBox listBox1;
        private Label label8;
        private Button buttonFind3;
    }
}