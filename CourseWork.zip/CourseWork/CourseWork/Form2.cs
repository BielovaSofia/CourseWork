﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Linq;

namespace CourseWork
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            string xmlFilePath = @"..\..\..\products.xml"; 
            LoadDataFromXml(xmlFilePath);
            productsDataGridView.ReadOnly = true;
            productsDataGridView.Columns["nameColumn"].DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            productsDataGridView.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            FillComboBoxWithProductNames();
        }

        private void Form2_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void LoadDataFromXml(string filePath)
        {
            try
            {
                XDocument xdoc = XDocument.Load(filePath);

                var products = xdoc.Descendants("Product");
                int invoiceNumber = 1;

                foreach (var product in products)
                {
                    productsDataGridView.Rows.Add(
                        invoiceNumber++,
                        product.Element("Name")?.Value,
                        product.Element("Maker")?.Value,
                        product.Element("ImportCountry")?.Value,
                        product.Element("BatchSize")?.Value,
                        product.Element("Date")?.Value
                    );
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Помилка завантаження даних з XML: " + ex.Message);
            }
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBoxName.Text) ||
                string.IsNullOrWhiteSpace(textBoxMaker.Text) ||
                string.IsNullOrWhiteSpace(textBoxCountry.Text) ||
                numericBatch.Value == 0)
            {
                MessageBox.Show("Будь ласка, заповніть всі поля.", "Попередження", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string productName = textBoxName.Text;
            string productMaker = textBoxMaker.Text;
            string importCountry = textBoxCountry.Text;
            int batchSize = (int)numericBatch.Value;
            DateTime supplyDate = dateTimePicker.Value;

            int invoiceNumber = 1;
            foreach (DataGridViewRow row in productsDataGridView.Rows)
            {
                if (!row.IsNewRow)
                {
                    invoiceNumber++;
                }
            }

            productsDataGridView.Rows.Add(
                invoiceNumber,
                productName,
                productMaker,
                importCountry,
                batchSize,
                supplyDate.ToShortDateString()
            );

            textBoxName.Clear();
            textBoxMaker.Clear();
            textBoxCountry.Clear();
            numericBatch.Value = 0;
            dateTimePicker.Value = DateTime.Now;

            FillComboBoxWithProductNames();
        }

        private void textBoxCountry_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void productsDataGridView_SelectionChanged(object sender, EventArgs e)
        {
            if (productsDataGridView.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = productsDataGridView.SelectedRows[0];

                if (!selectedRow.IsNewRow)
                {
                    textBoxName.Text = selectedRow.Cells["nameColumn"].Value.ToString();
                    textBoxMaker.Text = selectedRow.Cells["makerColumn"].Value.ToString();
                    textBoxCountry.Text = selectedRow.Cells["importCountryColumn"].Value.ToString();
                    numericBatch.Value = Convert.ToInt32(selectedRow.Cells["batchSizeColumn"].Value);
                    dateTimePicker.Value = Convert.ToDateTime(selectedRow.Cells["dateColumn"].Value);
                }
                else
                {
                    textBoxName.Clear();
                    textBoxMaker.Clear();
                    textBoxCountry.Clear();
                    numericBatch.Value = 0;
                    dateTimePicker.Value = DateTime.Now;
                }
            }
        }

        private void buttonRedact_Click(object sender, EventArgs e)
        {
            if (productsDataGridView.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = productsDataGridView.SelectedRows[0];


                selectedRow.Cells["nameColumn"].Value = textBoxName.Text;
                selectedRow.Cells["makerColumn"].Value = textBoxMaker.Text;
                selectedRow.Cells["importCountryColumn"].Value = textBoxCountry.Text;
                selectedRow.Cells["batchSizeColumn"].Value = numericBatch.Value;
                selectedRow.Cells["dateColumn"].Value = dateTimePicker.Value.ToShortDateString();

            }
            else
            {
                MessageBox.Show("Будь ласка, виберіть рядок для редагування.", "Попередження", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            FillComboBoxWithProductNames();
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            if (productsDataGridView.SelectedRows.Count > 0)
            {
                int selectedIndex = productsDataGridView.SelectedRows[0].Index;

                productsDataGridView.Rows.RemoveAt(selectedIndex);

                for (int i = 0; i < productsDataGridView.Rows.Count; i++)
                {
                    productsDataGridView.Rows[i].Cells[0].Value = i + 1;
                }
            }
            else
            {
                MessageBox.Show("Будь ласка, виберіть рядок для видалення.", "Попередження", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            FillComboBoxWithProductNames();
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            productsDataGridView.Rows.Clear();
        }

        private void buttonSaveXML_Click(object sender, EventArgs e)
        {
            string filePath = @"..\..\..\products.xml";

            try
            {
                XmlDocument xmlDocument = new XmlDocument();

                XmlElement rootElement = xmlDocument.CreateElement("root");
                xmlDocument.AppendChild(rootElement);

                foreach (DataGridViewRow row in productsDataGridView.Rows)
                {
                    if (!row.IsNewRow)
                    {
                        XmlElement productElement = xmlDocument.CreateElement("Product");
                        rootElement.AppendChild(productElement);

                        productElement.AppendChild(CreateXmlElement(xmlDocument, "Name", row.Cells["nameColumn"].Value.ToString()));
                        productElement.AppendChild(CreateXmlElement(xmlDocument, "Maker", row.Cells["makerColumn"].Value.ToString()));
                        productElement.AppendChild(CreateXmlElement(xmlDocument, "ImportCountry", row.Cells["importCountryColumn"].Value.ToString()));
                        productElement.AppendChild(CreateXmlElement(xmlDocument, "BatchSize", row.Cells["batchSizeColumn"].Value.ToString()));
                        productElement.AppendChild(CreateXmlElement(xmlDocument, "Date", row.Cells["dateColumn"].Value.ToString()));
                    }
                }

                xmlDocument.Save(filePath);

                MessageBox.Show("Дані збережено у файлі products.xml", "Інформація", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Помилка при збереженні файлу: " + ex.Message, "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private XmlElement CreateXmlElement(XmlDocument xmlDocument, string elementName, string elementValue)
        {
            XmlElement element = xmlDocument.CreateElement(elementName);
            element.InnerText = elementValue;
            return element;
        }

        private void buttonLoadXML_Click(object sender, EventArgs e)
        {
            string filePath = @"..\..\..\products.xml";
            productsDataGridView.Rows.Clear();

            try
            {
                LoadDataFromXml(filePath);

                MessageBox.Show("Дані завантажено з файлу products.xml", "Інформація", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Помилка при завантаженні файлу: " + ex.Message, "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            FillComboBoxWithProductNames();
        }

        private void FillComboBoxWithProductNames()
        {
            comboBoxProducts.Items.Clear();

            HashSet<string> uniqueProductNames = new HashSet<string>();

            foreach (DataGridViewRow row in productsDataGridView.Rows)
            {
                if (!row.IsNewRow)
                {
                    string productName = row.Cells["nameColumn"].Value.ToString();
                    uniqueProductNames.Add(productName);
                }
            }

            comboBoxProducts.Items.AddRange(uniqueProductNames.ToArray());
        }

        static int BinarySearch(int[] array, int searchedValue, int first, int last)
        {
            if (first > last)
            {
                return -1;
            }

            var middle = (first + last) / 2;
            var middleValue = array[middle];

            if (middleValue == searchedValue)
            {
                return middle;
            }
            else
            {
                if (middleValue > searchedValue)
                {
                    return BinarySearch(array, searchedValue, first, middle - 1);
                }
                else
                {
                    return BinarySearch(array, searchedValue, middle + 1, last);
                }
            }
        }

        private void buttonFind1_Click(object sender, EventArgs e)
        {
            FindDataGridView1.Rows.Clear();

            string selectedProductName = comboBoxProducts.SelectedItem?.ToString();

            if (string.IsNullOrEmpty(selectedProductName))
            {
                MessageBox.Show("Будь ласка, оберіть назву продукту зі списку.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            List<int> foundIndexes = new List<int>();

            for (int i = 0; i < productsDataGridView.Rows.Count - 1; i++)
            {
                if (string.Equals(productsDataGridView.Rows[i].Cells["nameColumn"].Value.ToString(), selectedProductName, StringComparison.OrdinalIgnoreCase))
                {
                    foundIndexes.Add(i);
                }
            }

            if (foundIndexes.Count > 0)
            {
                int totalBatchSize = 0;

                foreach (int index in foundIndexes)
                {
                    DataGridViewRow foundRow = productsDataGridView.Rows[index];
                    FindDataGridView1.Rows.Add(foundRow.Cells.Cast<DataGridViewCell>().Select(cell => cell.Value).ToArray());

                    totalBatchSize += Convert.ToInt32(foundRow.Cells["batchSizeColumn"].Value);
                }

                textBoxResult.Text = totalBatchSize.ToString();
            }
            else
            {
                MessageBox.Show($"Продукт \"{selectedProductName}\" не знайдено.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private List<int> FindProductNameIndexes(string[] array, string searchedValue)
        {
            List<int> indexes = new List<int>();

            for (int i = 0; i < array.Length; i++)
            {
                if (string.Equals(array[i], searchedValue, StringComparison.OrdinalIgnoreCase))
                {
                    indexes.Add(i);
                }
            }

            return indexes;
        }

        private void buttonFind2_Click(object sender, EventArgs e)
        {
            FindDataGridView2.Rows.Clear();

            DateTime startDate = dateTimePicker1.Value.Date;
            DateTime endDate = dateTimePicker2.Value.Date;

            List<DataGridViewRow> productsInRange = new List<DataGridViewRow>();

            foreach (DataGridViewRow row in productsDataGridView.Rows)
            {
                if (!row.IsNewRow)
                {
                    DateTime productDate = Convert.ToDateTime(row.Cells["dateColumn"].Value);

                    if (productDate >= startDate && productDate <= endDate)
                    {
                        productsInRange.Add(row);
                    }
                }
            }

            if (productsInRange.Count == 0)
            {
                MessageBox.Show("Продукти не знайдено у вказаному діапазоні дат.", "Інформація", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            var top5Products = productsInRange
                .OrderByDescending(row => Convert.ToInt32(row.Cells["batchSizeColumn"].Value))
                .Take(5)
                .ToList();

            if (top5Products.Count == 0)
            {
                MessageBox.Show("Продукти з найбільшим обсягом імпорту не знайдено.", "Інформація", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            string[] productNames = top5Products
                .Select(row => row.Cells["nameColumn"].Value.ToString())
                .ToArray();

            productNames = MergeSort(productNames);

            foreach (var productName in productNames)
            {
                var row = top5Products.First(r => r.Cells["nameColumn"].Value.ToString() == productName);
                FindDataGridView2.Rows.Add(row.Cells.Cast<DataGridViewCell>().Select(cell => cell.Value).ToArray());
            }
        }

        static void Merge(string[] array, int lowIndex, int middleIndex, int highIndex)
        {
            var left = lowIndex;
            var right = middleIndex + 1;
            var tempArray = new string[highIndex - lowIndex + 1];
            var index = 0;

            while ((left <= middleIndex) && (right <= highIndex))
            {
                if (string.Compare(array[left], array[right], StringComparison.Ordinal) < 0)
                {
                    tempArray[index] = array[left];
                    left++;
                }
                else
                {
                    tempArray[index] = array[right];
                    right++;
                }

                index++;
            }

            for (var i = left; i <= middleIndex; i++)
            {
                tempArray[index] = array[i];
                index++;
            }

            for (var i = right; i <= highIndex; i++)
            {
                tempArray[index] = array[i];
                index++;
            }

            for (var i = 0; i < tempArray.Length; i++)
            {
                array[lowIndex + i] = tempArray[i];
            }
        }

        static string[] MergeSort(string[] array, int lowIndex, int highIndex)
        {
            if (lowIndex < highIndex)
            {
                var middleIndex = (lowIndex + highIndex) / 2;
                MergeSort(array, lowIndex, middleIndex);
                MergeSort(array, middleIndex + 1, highIndex);
                Merge(array, lowIndex, middleIndex, highIndex);
            }

            return array;
        }

        static string[] MergeSort(string[] array)
        {
            return MergeSort(array, 0, array.Length - 1);
        }

        private void buttonFind3_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();

            DateTime twoMonthsAgo = DateTime.Now.AddMonths(-2);

            foreach (DataGridViewRow row in productsDataGridView.Rows)
            {
                if (!row.IsNewRow)
                {
                    DateTime importDate = Convert.ToDateTime(row.Cells["dateColumn"].Value);

                    if (importDate < twoMonthsAgo)
                    {
                        listBox1.Items.Add(row.Cells["nameColumn"].Value.ToString());
                    }
                }
            }

            if (listBox1.Items.Count == 0)
            {
                MessageBox.Show("Продукти, які не імпортували за останні два місяці, не знайдено.", "Інформація", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

    }
}
